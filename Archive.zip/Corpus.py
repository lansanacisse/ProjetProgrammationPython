import pandas as pd
import numpy as np
import math
import re
import nltk
import string

# def singleton(cls):
#     instances = [None]
#     def wrapper(*args, **kwargs):
#         if instances[0] is None:
#             instances[0] = cls(*args, **kwargs)
#         return instances[0]
#     return wrapper

# @singleton
class Corpus:
    def __init__(self, nom, authors, id2doc):
        """_summary_

        Args:
            nom (_type_): _description_
            authors (_type_): _description_
            id2doc (_type_): _description_
        """
        self.nom = nom
        self.authors = authors
        self.id2doc = id2doc
        self.ndoc = len(self.id2doc)
        self.naut = len(self.authors)

        self.voc = {}
        self.all = " ".join([doc.getTexte().replace("\n", " ") for doc in self.id2doc.values()])
        self.voc = self.vocab()
        self.dfTF = pd.DataFrame()
        self.dfTFIDF = pd.DataFrame()

    def __repr__(self):
        return f'Corpus {self.nom} with {self.ndoc} documents by {self.naut} authors'
    
    def getdfTfIdf(self):
        return self.dfTFIDF
    
    def getdfTf(self):
        return self.dfTF
    
    def getNom(self):
        return self.nom
    
    def getAuthors(self):
        return self.authors
    
    def getId2doc(self):
        return self.id2doc
    
    def getVoc(self):
        return self.voc
    
    def getNaut(self):
        return self.naut
    
    def getNdoc(self):
        return self.ndoc
    

    # def save(self, filepath):
    #     with open(filepath, "wb") as f:
    #         pickle.dump(self, f)
        

    # def load(cls, filepath):
    #     with open(filepath, "rb") as f:
    #         return pickle.load(f)

    def save(self):
       
        dico={"documents": [], "auteurs": [] }
        for doc in self.id2doc.values():
            dico["documents"].append(doc)
            dico["auteurs"].append(self.authors[doc.getAuteur()])
        df = pd.DataFrame.from_dict(dico)
        df.to_csv("{}.csv".format(self.nom))
    
    def load(self, titre = "out.csv"):
        df = pd.read_csv(titre)
        self.setNom(titre[:-4])
        df["documents"].apply(self.addDocument)
        df["auteurs"].apply(self.addAuteur)

        
    
    def search(self, mot):
        """ Cette fonction retourne les passages des documents contenant le mot-clef entré en paramètre

        Args:
            mot (_string_): mot-clef à rechercher dans les documents

        Returns:
            _list_:  Passage des documents contenant le mot-clef entré en paramètre
        """

        res = []
        for i in re.compile(r'\b{}\b'.format(str(mot)), re.IGNORECASE).finditer(self.all):
            p = i.span()
            res.append(self.all[p[0]-20:p[1]+20])
        return res
    
    def recherche(self, mot):
        passages = []
        texte = self.all.split(". ")
        for i in texte:
            if re.search(mot, i):
                passages.append(i)
        return passages


    
    def concordance(self, mot):
        """ Cette fonction construit concordancier pour uneexpression donnée

        Args:
            mot (_string_): mot-clef à rechercher dans les documents

        Returns:
            _df_: Passage des documents contenant le mot-clef entré en paramètre avec le contexte gauche et droit
        """
        liste= self.search(mot)
        dic = {"contexte gauche":[], "motif trouvé":[], "contexte droit":[]}
        for el in liste:
            dic["contexte gauche"].append("..."+el[:20])
            dic["motif trouvé"].append(el[20:-20])
            dic["contexte droit"].append(el[-20:]+"...")
        df = pd.DataFrame.from_dict(dic)
        return df


    def vocabulary(self):
        """ retourne le vocabulaire de chaque document

        Returns:
            _dict_:  vocabulaire de chaque document 
        """
        voc = { k: list(set(self.nettoyer_texte(v.getTexte()).split())) for k,v in self.id2doc.items() }
        return voc
    
    def vocab(self):
       
        mots = re.split(r"\s+", self.nettoyer_texte(self.all))
        res = {}
        i=0
        for value in sorted(set(mots)):
            if value!="":
                res[value] = {"id": i, "term-frequency":0, "document-frequency":0}
                i+=1
        return res
    
    def occurence(self):
        """ retourne l'occurence de chaque mot dans le corpus

        Returns:
            _dict_:  occurence de chaque mot dans le corpus
        """
        tout = self.nettoyer_texte(self.all).split()
        voc = list(set(tout))
        occ = { k: tout.count(k) for k in voc }
        return occ
    
    # donne des stats à propos des docs :
    def stat(self):
        """
        @brief : Calcul les statistiques du Corpus
        """
        reddit = 0
        arxiv = 0
        mots, motsbis = 0, len(self.all)
        for doc in self.id2doc.values():
            texte = doc.getTexte()
            if doc.getType() == "Reddit":
                reddit += 1
                mots += len(texte.split())
                arxiv += 1
                motsbis += len(texte.split())
        return f"\nLes documents de type reddit sont {reddit} et ont en moyenne {mots} mots " \
            +f"\nLes documents de type arxiv sont {arxiv} et ont en moyenne {motsbis} mots "

    
    #nettoyer un texte passé en paramètre
    def nettoyer_texte(self, texte):
        """
        @param texte: texte à nettoyer
        @brief : Nettoie le texte passé en paramètre
        """
        compiler = re.compile("[%s]"%re.escape(string.punctuation))
        #mettre tout sur la même ligne et mettre en minuscule
        texte = texte.lower().replace("\n", " ")
        #enlever les ponctuations su texte
        texte = compiler.sub(" ", texte)
        #retirer les espacements inutile
        texte.replace("\t", " ")
        token = [t for t in texte.split() if t.isalpha()]
        #raciniser les mots
        stemmer = nltk.stem.SnowballStemmer("english")
        token = [stemmer.stem(mot) for mot in token]
        texte = " ".join(token)
        return texte
    

    def score(self, mot):
        """
        @param mot: mot clé
        @brief : Calcul le score du mot clé par rapport aux Documents du Corpus
        """
        mot = self.nettoyer_texte(mot).split()
        q = np.array([self.all.count(m) for m in self._mots])
        if sum (q) == 0:
            return 0
        
        mat = self.matdoc
        res = mat @ q
        res = res / (len(mat[0]) * sum(q))
        arg = np.argsort(res)
        return arg[-3:]

    def matrice(self):
        """
        @brief : Calcul la matrice tf-idf du Corpus
        """
        mat_TF = {}

        for doc in self.id2doc.values():
            mat_TF[doc.getTitre()] = {}

            docText = doc.getTexte()
            chaineCleaned = self.nettoyer_texte(docText)
            splitedWords = re.split('\s+', chaineCleaned) # split la liste avec espaces

            deja_vu = []

            for word in self.voc.keys(): # initialisation
                mat_TF[doc.getTitre()][word] = 0

            for word in splitedWords:
                mat_TF[doc.getTitre()][word] = 0 
                if word in self.voc.keys(): # il est dans le vocabulaire
                    self.voc[word]['term-frequency'] += 1
                    if word not in deja_vu: # première fois que l'on tombe dessus dans le document
                        nbOccurence = splitedWords.count(word) # on compte directement tout les mêmes mots d'un texte
                        mat_TF[doc.getTitre()][word] = nbOccurence
                        deja_vu.append(word)
                        self.voc[word]['document-frequency'] += 1

        
        tf_idf = {}

        # calcul de la fréquence de chaque mot dans chaque document
        for doc in self.id2doc.values():
            chaineCleaned = self.nettoyer_texte(doc.getTexte())
            splitedWords = chaineCleaned.split() # split la liste avec espaces
            for word in splitedWords:
                if word in tf_idf:
                    tf_idf[word]['doc_count'] += 1
                else:
                    tf_idf[word] = {'doc_count': 1}

        # calcul de la fréquence de chaque mot dans tous les documents
        for word, scores in tf_idf.items():
            # tout les mots qui ne sont pas dans le
            # mettre à 0 les mots qui manquent au vocabulaire
            
            total_count = 0
            for doc in self.id2doc.values():
                texte_doc = doc.getTexte()
                if word in texte_doc:
                    total_count += 1
            # Assignation de la valeur calculée au dictionnaire tf_idf pour le mot spécifique
            tf_idf[word]['total_count'] = total_count

        # dictionnaire qui contiendra les mots et leur score idf
        idf_scores = {}

        # calcul du score idf pour chaque mot
        for word, scores in tf_idf.items():
            #print(scores['total_count'])
            if scores['total_count'] == 0:
                idf_scores[word] = 0
            else:
                idf_scores[word] = math.log(len(self.id2doc) / scores['total_count'])

        # création de la matrice tf-idf
        mat_TFIDF = {}
        for doc in self.id2doc.values():
            mat_TFIDF[doc.getTitre()] = {}
            chaineCleaned = self.nettoyer_texte(doc.getTexte())
            splitedWords = chaineCleaned.split() # split la liste avec espaces
            for word in self.voc.keys(): # initialisation
                mat_TFIDF[doc.getTitre()][word] = 0
            for word in splitedWords:
                tf = tf_idf[word]['doc_count'] / len(splitedWords)
                idf = idf_scores[word]
                mat_TFIDF[doc.getTitre()][word] = tf * idf

        dfTF = pd.DataFrame(mat_TF) 
        dfTFIDF = pd.DataFrame(mat_TFIDF) 

        self.dfTF = dfTF
        self.dfTFIDF = dfTFIDF

    # TF-IDF method
    def tf(self, i, mot, voc):
        doc= voc[i]
        nb= doc.count(mot)
        total= len(doc)
        if total==0:
            return 0
        return nb/total
    
    def idf(self, mot, voc):
        D = len(voc)
        d = 0
        for document in voc.values():
            if document.count(mot) > 0:
                d += 1
        return math.log(D/d)
    
    def mat_TFIDF(self):
        """
        @brief : Calcul la matrice TF-IDF du Corpus
        """
        voc=self.vocabulary()
        n = self.ndoc
        mots = self._mots
        mat = np.zeros((n, len(mots)))
        for i in range(n):
            for j, c in enumerate(mots):
                mat[i][j] = self.tf(i, c, voc)*self.idf(c, voc)
        return mat
    

    def searchCosine(self, keywords):
        """
        @param keywords: liste de mots clés
        @brief : Recherche les documents les plus similaires aux mots clés
        """
        # Création du vecteur pour les mots-clés
        # 1 si le mot est dans les mots-clés, 0 sinon
        vecteur_mots_cles = [1 if mot in keywords else 0 for mot in self.voc]

        # Génération des vecteurs pour chaque document
        vecteurs_documents = {}
        for document in self.id2doc.values():
            titre_doc = document.getTitre()
            texte_nettoye = self.nettoyer_texte(document.getText())
            mots_document = texte_nettoye.split()

            # Création du vecteur binaire pour le document
            vecteur_doc = [1 if mot in mots_document else 0 for mot in self.vocab]
            vecteurs_documents[titre_doc] = vecteur_doc

        # Calcul de la similarité cosinus
        resultats_similarite = {}
        for titre, vecteur in vecteurs_documents.items():
            norme_vecteur_mot_cles = np.linalg.norm(vecteur_mots_cles)
            norme_vecteur_doc = np.linalg.norm(vecteur)

            if norme_vecteur_mot_cles * norme_vecteur_doc == 0:
                similarite_cosinus = 0
            else:
                similarite_cosinus = (vecteur_mots_cles @ vecteur) / (norme_vecteur_mot_cles * norme_vecteur_doc)
            resultats_similarite[titre] = similarite_cosinus

        # Tri des résultats par similarité décroissante
        documents_tries_par_similarite = dict(sorted(resultats_similarite.items(), key=lambda x: x[1], reverse=True))

        return documents_tries_par_similarite


    # def vector_transformation(self, kw):
    #     """
    #     @param kw: mot clé
    #     @brief : Calcul le vecteur TF-IDF du mot clé par rapport aux Documents du Corpus
    #     @return: vecteur TF-IDF du mot clé
    #     """
    #     tf_list = list()  # vecteur tf pour le motcle
    #     doc_contains = 0  # documents qui contiennent le mot
    #     idf = list()  # vecteur idf pour le motcle
    #     tf_idf = [None] * self.ndoc  # liste pour le vecteur final

    #     for doc in self.id2doc.values():
    #         tf = 0  # term frequency du document
    #         # On récupere le texte
    #         texte = doc.getTexte()
    #         # On le nettoie
    #         cleaned_texte = self.nettoyer_texte(texte)
    #         # On le decoupe en mots
    #         mots = re.split("[ \t,;\.]", cleaned_texte)

    #         for mot in mots:
    #             if mot == kw:
    #                 tf += 1
    #         # term frequency of document
    #         tf_list.append(tf / len(mots))
    #         # Si le mot est dans le doc on augment son df
    #         if kw in doc.texte.split():
    #             doc_contains += 1

    #         # On peut alors calculer le idf
    #         idf.append(np.log10(self.ndoc / (doc_contains + 1)))

    #     tf_list.copy()

    #     # On peut alors calculer le tf_idf de chaque document
    #     for i in range(self.ndoc):
    #         tf_idf[i] = tf_list[i] * idf[i]

    #     return tf_idf
    

    def matDocumentMot(self):
        """
        @brief : Calcul la matrice Document-Mot du Corpus
        """
        mots = self._mots
        voc = self.vocabulary()
        mat = np.zeros((len(self.id2doc), len(mots)))
        for l in range(len(self.id2doc)):
            document = voc[l]
            for c, mot in enumerate(mots):
                mat[l][c] = document.count(mot)
        return mat
    

    def occurenceMot(self):
        """
        @brief : Calcul l'occurence de chaque mot dans le Corpus
        """
        mat = self.matdoc
        result = []
        for i in range(len(mat)):
            nbDocu = 0
            nbTotal = 0
            mot = self._mots[i]
            for x in mat[:, i]:
                if x != 0:
                    nbDocu += 1
                nbTotal += x
            result.append((mot, nbDocu, nbTotal))
        return result
    
    def get_id2doc_DF(self):
        """
        @brief : Retourne le dictionnaire id2doc
        @return: dataframe du dictionnaire id2doc
        """

        df = pd.DataFrame(columns=['Id','Nom','Auteur','Date','dateFr','URL','Text','Textabrv','Type'])
        i=1
        for doc in self.id2doc.values():
            row = [i,doc.getTitre(),doc.getAuteur(),doc.getDate().date(),doc.getDate().strftime("%d/%m/%y"),doc.getUrl(), doc.getTexte(), doc.getTexte()[:10]+'...',doc.getType()]
            df.loc[len(df)] = row
            i+=1
        return df
    

    