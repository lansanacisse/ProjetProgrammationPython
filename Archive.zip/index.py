import pickle
import Corpus
from importlib import reload
# import numpy as np
# import pandas as pd
from dash import Dash, dash_table, dcc, html
from dash.dependencies import Input, Output, State
from datetime import datetime

reload(Corpus) # Reload the module to ensure that the latest changes are used

app = Dash(__name__)    # Create a Dash instance
# Ouverture du fichier, puis lecture avec pickle
with open("./data/id2doc.pkl", "rb") as f:
    id2doc = pickle.load(f)
    f.close()


# Ouverture du fichier, puis lecture avec pickle
with open("./data/id2author.pkl", "rb") as f:
    id2aut = pickle.load(f)
    f.close()


corpus = Corpus.Corpus("Machine-Learning",id2aut,id2doc)

corpus.matrice()
dfid2doc = corpus.get_id2doc_DF()

dfReddit, dfArxiv = dfid2doc[dfid2doc["Type"]=="Reddit"], dfid2doc[dfid2doc["Type"]=="Arxiv"]
n_doc = len(corpus.id2doc)

print(f"Stats générales du corpus: {corpus.stat()}")


auteurReddit = dfReddit["Auteur"].unique()
auteurArxiv = dfArxiv["Auteur"].unique()

statsVoc = list()
statsVoc.append("Taille du vocabulaire : "+str(len(corpus.voc)))
statsVoc.append(html.Br())
statsVoc.append(corpus.stat())
statsVoc.append(html.Br())
statsVoc.append(html.Br())

statsVoc.append("Les 15 plus grandes sommes de TF-IDF : ")
statsVoc.append(html.Br())
statsVoc.append(html.Br())

dictTFIDF = dict()
for indx, row in corpus.getdfTfIdf().iterrows():
    dictTFIDF[indx] = row.sum()

for k, v in sorted(dictTFIDF.items(), key=lambda item: item[1], reverse=True)[:15]:
    l = html.Label(k+" : TF-IDF = "+str(round(v, 2)))
    statsVoc.append(l)
    statsVoc.append(html.Br())

app.layout = html.Div([dcc.Dropdown(
    id = 'cbMenu',
    options = [
        {'label': 'General Information', 'value': 'generalInfo'},
        {'label': 'Document-wise Corpus Details', 'value': 'docDetail'}
    ],
    value = 'generalInfo'
),html.Div(id="divInfos",children=[html.Center([html.H1('General Informations'),
                                            html.Label("Cette application dispose d'un moteur de recherche permettant de comparer différentes statistiques en fonction"),html.Br(),
                                            html.Label("de mot clés tapés dans une barre de recherche (utilisez la liste déroulante du dessus afin de changer de menu)"),html.Br(),
                                            html.Label("les corpus sont les suivants :")]),html.Br(),html.Br(),
                                                html.Div([html.Center([html.H2('Corpus "ML" Reddit'),
                                            html.Label("Ce corpus de document contient les "+ str(int(n_doc/2)) +" premiers documents",style={'font-size':'20px'}),html.Br(),
                                            html.Label("en recherchant le mot clé \"ML\" sur Reddit",style={'font-size':'20px'})])],style={'float':'left','width':'49.5%','height':'20%','border-right': 'solid 0.5px'}),
                                                html.Div([html.Center([html.H2('Corpus "ML" Arxiv'),
                                            html.Label("Ce corpus de document contient les "+ str(int(n_doc/2)) +" premiers documents",style={'font-size':'20px'}),html.Br(),
                                            html.Label("en recherchant le mot clé \"ML\" sur Arxiv",style={'font-size':'20px'})],style={'float':'right','width':'49.5%','height':'20%','position':'relative'})]),
                                                html.Div([html.Center([html.H2("Statistiques générales"),html.Div(id="divStats",children=statsVoc)])],style={'position':'absolute','width':'100%','height':'80%','top':'45%'})],style={'z-index':'1','width':'100%','height':'20%','position':'absolute','background-color':'white'}),
                                                html.Div(id='mainDocDetails',children=[
    html.Div([
        dcc.Input(id='txtSearch',type='text',placeholder='Saisir les mots clés...',style={'margin':'0 auto','display':'block','margin-bottom':'5px'}),
        html.Div([
            html.Div(
                dcc.Dropdown(auteurReddit,id='cbAuteurLeft',style={'width':'120px','margin-left':'calc(50% + 10px)'})
                , style={'float':'left','width':'30%'}),
            html.Div([
                dcc.Dropdown(auteurArxiv,id='cbAuteurRight',style={'width':'120px','margin-left':'calc(50% - 120px)'})
                ,
                html.Button('Rechercher', id='btnFilter', n_clicks=None,style={'float':'right'}),
                html.Button('Effacer les filtres', id='btnClear', n_clicks=None,style={'float':'right'})],style={'float':'right','width':'30%'}),
            html.Center([
                dcc.DatePickerRange(
                    display_format='DD/MM/YYYY',
                    end_date_placeholder_text='DD/MM/YYYY',
                    start_date = min(dfid2doc['Date']),
                    end_date = max(dfid2doc['Date']),
                    min_date_allowed = min(dfid2doc['Date']),
                    max_date_allowed = max(dfid2doc['Date']),
                    id="dateFilter")
            ]),
        ]),html.Br()
    ],id="divSearch", style={'float':'top','width':'100%','height':'10%','border-style':'solid'}),
    html.Div([html.Br(),html.Center('Corpus "ML" de Reddit',style={'font-size':'30px','font-weight':'bold'}),html.Br(),
              dash_table.DataTable(
                  id='tableReddit',page_size=5,page_action='native',
                  data=dfReddit.to_dict('records'),     
                  columns=[
                      {'id': 'Id', 'name': 'ID'},
                      {'id': 'Nom', 'name': 'Titre'},
                      {'id': 'Auteur', 'name': 'Auteur'},
                      {'id': 'dateFr', 'name': 'Date'},
                      {'id': 'URL', 'name': 'URL'},
                      {'id': 'Textabrv', 'name': 'Texte'},
                  ],style_cell={"width":"5px",'minWidth':'5px','maxWidth':'5px'},style_table={'width':'99.5%'}),html.Div(id='divDetailsLeft',children=[html.Div(id='divWordsLeft')],style={'display':'none','float':'left','width':'50%','height':'100%'})],id="divLeft",style={'z-index':'0','float':'left','width':'50%','height':'45%'}),
    html.Div([html.Br(),html.Center('Corpus "ML" d\'Arxiv',style={'font-size':'30px','font-weight':'bold'}),html.Br(),
              dash_table.DataTable(
                  id='tableArxiv',page_size=5,page_action='native',
                  data=dfArxiv.to_dict('records'),     
                  columns=[
                      {'id': 'Id', 'name': 'ID'},
                      {'id': 'Nom', 'name': 'Titre'},
                      {'id': 'Auteur', 'name': 'Auteur' },
                      {'id': 'dateFr', 'name': 'Date'},
                      {'id': 'URL', 'name': 'URL'},
                      {'id': 'Textabrv', 'name': 'Texte'},
                  ],style_cell={"width":"5px",'minWidth':'5px','maxWidth':'5px'},style_table={'width':'99.5%'}),html.Div(id='divDetailsRight',children=[html.Div(id='divWordsRight')],style={'display':'block','float':'right','width':'50%','height':'100%'})],id="divRight",style={'float':'right','width':'50%','height':'90%',"display":"block"})],style={'z-index':'-1'})])

@app.callback(
    Output('tableReddit', 'data'),
    Output('tableArxiv', 'data'),
    State('cbAuteurLeft', 'value'),
    State('cbAuteurRight', 'value'),
    State('txtSearch', 'value'),
    State('dateFilter', 'start_date'),
    State('dateFilter', 'end_date'),
    Input('btnFilter', 'n_clicks'),
)
def callback_func(cbAuteur_value_left,cbAuteur_value_right,keywords,start,end,clicks):
    df_filtered_1 = dfReddit.copy()
    df_filtered_2 = dfArxiv.copy()

    start_val = ''
    end_val=''

    print(start)
    print(end)

    if cbAuteur_value_left:
        df_filtered_1 = df_filtered_1[df_filtered_1['Auteur'].eq(cbAuteur_value_left)]
    if cbAuteur_value_right:
        df_filtered_2 = df_filtered_2[df_filtered_2['Auteur'].eq(cbAuteur_value_right)]

    if not(start):
        start_val = datetime.date(min(dfid2doc['Date']))
    else:
        start_val = datetime.strptime(start, "%Y-%m-%d").date()
    if not(end):
        end_val = datetime.date(min(dfid2doc['Date']))
    else:
        end_val = datetime.strptime(end, "%Y-%m-%d").date()

    df_filtered_1=df_filtered_1[(df_filtered_1['Date'] >=start_val) & (df_filtered_1['Date']<=end_val)]
    df_filtered_2=df_filtered_2[(df_filtered_2['Date'] >=start_val) & (df_filtered_2['Date']<=end_val)]

    if keywords:
        print('---------------------',keywords)
        keywords_clean = corpus.nettoyer_texte(keywords)
        arr_keywords=keywords_clean.split(" ")
        dictest=corpus.recherche(arr_keywords)
        df_filtered_1['score'] = df_filtered_1['Nom'].apply(lambda x:dictest[x])
        df_filtered_2['score'] = df_filtered_2['Nom'].apply(lambda x:dictest[x])
        dfReddit['score']=dfReddit['Nom'].apply(lambda x:dictest[x])
        dfArxiv['score']=dfArxiv['Nom'].apply(lambda x:dictest[x])
        df_filtered_1 = df_filtered_1.sort_values('score',ascending=False)
        df_filtered_2 = df_filtered_2.sort_values('score',ascending=False)

        if cbAuteur_value_left:
            df_filtered_1 = df_filtered_1[df_filtered_1['Auteur'].eq(cbAuteur_value_left)]
        if cbAuteur_value_right:
            df_filtered_2 = df_filtered_2[df_filtered_2['Auteur'].eq(cbAuteur_value_right)]

    df_filtered_1=df_filtered_1[(df_filtered_1['Date'] >= start_val) & (df_filtered_1['Date']<= end_val)]
    df_filtered_2=df_filtered_2[(df_filtered_2['Date'] >= start_val) & (df_filtered_2['Date']<= end_val)]

    return df_filtered_1.to_dict(orient='records'),df_filtered_2.to_dict(orient='records')


@app.callback(
    [Output('authorDropdownLeft', 'value'),
     Output('authorDropdownRight', 'value'),
     Output('keywordInput', 'value'),
     Output('datePicker', 'start_date'),
     Output('datePicker', 'end_date')],
    [State('authorDropdownLeft', 'value'),
     State('authorDropdownRight', 'value'),
     State('keywordInput', 'value'),
     State('datePicker', 'start_date'),
     State('datePicker', 'end_date')],
    [Input('resetButton', 'n_clicks')]
)
def clear_filters(selected_author_left, selected_author_right, search_keywords, start_date, end_date, reset_clicks):
    """
    @brief Clear all filters
    @param selected_author_left The selected author in the left dropdown
    """
    # Check if any filter is applied and reset is clicked
    initial_start_date = min(dfid2doc['Date'])
    initial_end_date = max(dfid2doc['Date'])
    if reset_clicks and (selected_author_left or selected_author_right or search_keywords or 
                         datetime.strptime(start_date, "%Y-%m-%d").date() != initial_start_date or 
                         datetime.strptime(end_date, "%Y-%m-%d").date() != initial_end_date):
        # Reset all filters to their initial state
        return '', '', '', initial_start_date, initial_end_date
    # If no reset clicked or no filters are applied, keep the current state
    return selected_author_left, selected_author_right, search_keywords, start_date, end_date


@app.callback(
    [Output("detailViewLeft", "children"),
     Output("wordFreqLeft", "children"),
     Output("detailViewLeft", "style")],
    Input('redditTable', 'active_cell'),
    [State('redditTable', 'data'),
     State('keywordInput', 'value'),
     State('redditTable', 'page_current'),
     State('redditTable', 'page_size')]
)
def update_left_panel(active_cell, table_data, keywords, current_page, page_size):
    """
    @brief Update the left panel based on the selected cell in the Reddit table
    """
    result = ()
    if active_cell:
        row_index = active_cell['row'] + (current_page * page_size if current_page is not None else 0)
        selected_id = table_data[row_index]['Id']

        document_text = dfReddit.loc[dfReddit['Id'] == selected_id, 'Text'].values[0]
        num_comments = dfReddit.loc[dfReddit['Id'] == selected_id, 'Comments'].values[0]

        if keywords:
            document_score = dfReddit.loc[dfReddit['Id'] == selected_id, 'score'].values[0]
            score_color = calculate_score_color(document_score)

            tfidf_display = [html.B('TFxIDF for keywords:', style={'font-size': '20px'}), html.Br()]
            cleaned_keywords = corpus.nettoyer_texte(keywords).split(" ")

            for word in cleaned_keywords:
                word_tfidf, color = fetch_tfidf_and_color(word, selected_id)
                tfidf_display.append(html.Label(children=[word + ': ', word_tfidf],
                                                style={'margin-left': '20px', 'background-color': color, 'font-size': '20px'}))
                tfidf_display.append(html.Br())

            result = (compose_detail_view(document_text, num_comments, document_score, score_color), 
                      html.Div(children=tfidf_display), {'display': 'block'})
        else:
            result = (compose_detail_view(document_text, num_comments), html.Div(), {'display': 'block', 'border-right': 'solid 0.5px'})
    return result

# Helper functions used in the callback
def calculate_score_color(score):
    """
    @brief Determine the color of the score label based on the score value
    """
    if score == 0.00:
        return 'rgb(220,220,220)'
    elif score <= 0.25:
        return 'rgb(176,242,182)'
    elif score <= 0.5:
        return 'rgb(104,230,116)'
    else:
        return 'rgb(47,221,63)'

def fetch_tfidf_and_color(word, doc_id):
    """
    @brief Fetch the TFxIDF value for a given word and document
    """
    tfxidf_value = corpus.getdfTfIdf().loc[word, dfReddit[dfReddit['Id'] == doc_id]['Nom']].values[0]
    if tfxidf_value == 0.0:
        color = 'rgb(220,220,220)'
    elif tfxidf_value <= 0.25:
        color = 'rgb(176,242,182)'
    elif tfxidf_value <= 0.5:
        color = 'rgb(104,230,116)'
    else:
        color = 'rgb(47,221,63)'

    return tfxidf_value, color

def compose_detail_view(doc_text, num_comments, doc_score=None, score_color=None):
    """
    @brief Compose the detail view for a document
    """
    detail_elements = [
        html.Center([html.B('Full text:', style={'font-size': '25px'}), html.Br()]),
        dcc.Textarea(style={'font-size': '20px'}, value=doc_text, rows=10, cols=30),
        html.Br(),
        html.Label('Number of comments: ' + str(num_comments))
    ]

    # Add score details if provided
    if doc_score is not None and score_color is not None:
        score_element = html.Center([
            html.B('Score:', style={'font-size': '25px'}),
            html.Label(children=[doc_score], style={'background-color': score_color, 'font-size': '20px'}),
            html.Br()
        ])
        detail_elements.insert(0, score_element)

    return html.Div(detail_elements)


@app.callback(
    [Output("rightDetailsDiv", "children"),
     Output("rightKeywordsDiv", "children"),
     Output("rightDetailsDiv", "style")],
    Input('arxivTable', 'active_cell'),
    [State('arxivTable', 'data'),
     State('searchInput', 'value'),
     State('arxivTable', 'page_current'),
     State('arxivTable', 'page_size')]
)
def update_right_panel(selected_cell, table_data, search_text, current_page, page_size):
    """
    @brief Update the right panel based on the selected cell in the Arxiv table
    """
    result_content = ()
    if selected_cell:
        row_index = selected_cell['row'] + (current_page * page_size if current_page is not None else 0)
        doc_id = table_data[row_index]['Id']
        document_text = dfArxiv[dfArxiv['Id'] == doc_id]['Text'].iloc[0]
        co_authors = ' - '.join(dfArxiv[dfArxiv['Id'] == doc_id]['Features'].values[0])

        if search_text:
            doc_score = dfArxiv[dfArxiv['Id'] == doc_id]['score'].iloc[0]
            score_color = determine_color_based_on_score(doc_score)

            tfidf_data = corpus.getdfTfIdf().copy()
            keyword_tfidf_elements = prepare_tfidf_elements(search_text, doc_id, tfidf_data)

            result_content = (
                build_document_details(document_text, co_authors, doc_score, score_color),
                html.Div(children=keyword_tfidf_elements),
                {'display': 'block'}
            )
        else:
            result_content = (
                build_document_details(document_text, co_authors),
                html.Div(),
                {'display': 'block', 'border-left': 'solid 0.5px'}
            )

    return result_content

# Additional helper functions
def determine_color_based_on_score(score):
    """
    @brief Determine the color of the score label based on the score value
    """
    if score == 0.00:
        return 'rgb(220,220,220)'
    elif score <= 0.25:
        return 'rgb(176,242,182)'
    elif score <= 0.5:
        return 'rgb(104,230,116)'
    else:
        return 'rgb(47,221,63)'

def prepare_tfidf_elements(search_text, doc_id, tfidf_data):
    """
    @brief Prepare the TFxIDF elements for the right panel
    """
    cleaned_keywords = corpus.nettoyer_texte(search_text).split(" ")
    tfidf_elements = [html.B('TFxIDF of Keywords:', style={'font-size': '20px'}), html.Br()]

    for word in cleaned_keywords:
        if word in tfidf_data.index:
            tfxidf_value = tfidf_data.loc[word, dfArxiv[dfArxiv['Id'] == doc_id]['Name']].values[0]
            color_tfxidf = determine_color_based_on_score(tfxidf_value)

            element = html.Label(children=[word + ' : ', tfxidf_value],
                                 style={'margin-left': '20px', 'background-color': color_tfxidf, 'font-size': '20px'})
        else:
            element = html.Label(children=[word + ' : ', 0.0],
                                 style={'margin-left': '20px', 'background-color': 'rgb(220,220,220)', 'font-size': '20px'})

        tfidf_elements.extend([element, html.Br()])

    return tfidf_elements


def build_document_details(text, authors, score=None, color=None):
    """
    @brief Build the document details section
    """
    details = [
        html.Center([html.B('Full Text:', style={'font-size': '25px'}), html.Br()]),
        dcc.Textarea(style={'font-size': '20px'}, value=text, rows=10, cols=30),
        html.Br(),
        html.Label('Co-authors: ' + authors)
    ]
    # Include score details if provided
    if score is not None and color is not None:
        score_element = html.Center([
            html.B('Score:', style={'font-size': '25px'}),
            html.Label(children=[score], style={'background-color': color, 'font-size': '20px'}),
            html.Br()
        ])
        details.insert(0, score_element)
    return html.Div(details)

# df = pd.DataFrame.from_dict(vocab)
# column_names = df.columns.values.tolist()
# df = df.transpose()
# df.insert(0, "Mot", column_names)

@app.callback(
    Output('divInfos', 'style'),
    [Input('cbMenu', 'value')]
)
def adjust_div_visibility(selected_option):
    """
    @brief Adjust the visibility of the divInfos div based on the selected menu option
    @param selected_option The selected menu option
    """
    # Define common style properties
    common_style = {
        'z-index': '1',
        'width': '100%',
        'height': '100%',
        'position': 'absolute',
        'background-color': 'white'
    }
    # Adjust visibility based on the selected menu option
    if selected_option == 'generalInfo':
        return {**common_style, 'display': 'block'}
    elif selected_option == 'docDetail':
        return {**common_style, 'display': 'none'}
    


if __name__ == "__main__":
    app.run(host='127.0.0.1', port=8080)